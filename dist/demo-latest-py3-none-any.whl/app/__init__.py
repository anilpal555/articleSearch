"""
This package provides calculator functions
"""
